#include <iostream>
#include <vector>
#include <string>
using namespace std;

void displayTasks(const vector<string>& tasks) {
    cout << "\nTo-Do List:\n";
    for (int i = 0; i < tasks.size(); i++) {
        cout << i + 1 << ". " << tasks[i] << "\n";
    }
}

int main() {
    vector<string> tasks;
    int choice;
    string task;

    while (true) {
        cout << "\n1. Add Task\n2. View Tasks\n3. Delete Task\n4. Exit\nChoose: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            cout << "Enter task: ";
            getline(cin, task);
            tasks.push_back(task);
        } else if (choice == 2) {
            displayTasks(tasks);
        } else if (choice == 3) {
            int taskNum;
            cout << "Enter task number to delete: ";
            cin >> taskNum;
            if (taskNum > 0 && taskNum <= tasks.size()) {
                tasks.erase(tasks.begin() + taskNum - 1);
                cout << "Task deleted.\n";
            } else {
                cout << "Invalid task number.\n";
            }
        } else if (choice == 4) {
            break;
        } else {
            cout << "Invalid choice.\n";
        }
    }
    return 0;
}
