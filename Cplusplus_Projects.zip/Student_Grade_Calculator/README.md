# Student Grade Calculator
This C++ program calculates the average marks of a student and assigns a letter grade based on the average.