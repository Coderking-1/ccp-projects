#include <iostream>
#include <vector>
#include <string>
using namespace std;

char calculateGrade(double average) {
    if (average >= 90) return 'A';
    else if (average >= 80) return 'B';
    else if (average >= 70) return 'C';
    else if (average >= 60) return 'D';
    else return 'F';
}

int main() {
    int numSubjects;
    cout << "Enter number of subjects: ";
    cin >> numSubjects;

    vector<double> marks(numSubjects);
    double sum = 0;

    for (int i = 0; i < numSubjects; i++) {
        cout << "Enter marks for subject " << i + 1 << ": ";
        cin >> marks[i];
        sum += marks[i];
    }

    double average = sum / numSubjects;
    char grade = calculateGrade(average);

    cout << "Average Marks: " << average << endl;
    cout << "Final Grade: " << grade << endl;

    return 0;
}
