#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string owner;
    double balance;
public:
    BankAccount(string name, double initialBalance) {
        owner = name;
        balance = initialBalance;
    }
    void deposit(double amount) {
        balance += amount;
        cout << "Deposited: " << amount << "\n";
    }
    void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: " << amount << "\n";
        } else {
            cout << "Insufficient funds.\n";
        }
    }
    void displayBalance() {
        cout << "Owner: " << owner << ", Balance: " << balance << "\n";
    }
};

int main() {
    BankAccount account("John Doe", 500);
    account.displayBalance();
    account.deposit(200);
    account.withdraw(100);
    account.displayBalance();
    account.withdraw(700);

    return 0;
}
