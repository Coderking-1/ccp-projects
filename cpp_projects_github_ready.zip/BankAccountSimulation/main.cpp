#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string owner;
    double balance;
public:
    BankAccount(string name, double initialBalance) {
        owner = name;
        balance = initialBalance;
    }

    void deposit(double amount) {
        balance += amount;
        cout << "Deposited: " << amount << endl;
    }

    void withdraw(double amount) {
        if(amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: " << amount << endl;
        } else {
            cout << "Insufficient balance" << endl;
        }
    }

    void displayBalance() {
        cout << owner << "'s Balance: " << balance << endl;
    }
};

int main() {
    BankAccount account("John Doe", 1000);

    account.displayBalance();
    account.deposit(500);
    account.withdraw(200);
    account.withdraw(2000);
    account.displayBalance();

    return 0;
}
