#include <iostream>
#include <string>
using namespace std;

int main() {
    string name;
    double score1, score2, score3;

    cout << "Enter student name: ";
    getline(cin, name);

    cout << "Enter three scores: ";
    cin >> score1 >> score2 >> score3;

    double average = (score1 + score2 + score3) / 3.0;

    cout << "Average score for " << name << " is " << average << endl;

    if (average >= 60) {
        cout << "Result: Pass" << endl;
    } else {
        cout << "Result: Fail" << endl;
    }

    return 0;
}
